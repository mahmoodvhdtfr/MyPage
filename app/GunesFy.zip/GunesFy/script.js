// ====== صحیفه‌نین اؤزوندن آشاغی اسکرول اولماسینین حل‌ی ======
function scrollToTop() {
    // صحیفه‌نین باشینا اسکرول ائتمک
    window.scrollTo({
        top: 0,
        left: 0,
        behavior: 'smooth'
    });
    
    // مناسب المنت‌ده فوکوس (آختاریش کیمی)
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        setTimeout(() => {
            searchInput.focus();
        }, 100);
    }
}

// صحیفه کامیل لود اولاندا
window.addEventListener('load', function() {
    console.log("صحیفه کامیل لود اولدو - باشا اسکرول");
    scrollToTop();
});

// DOM حاضیر اولاندا
document.addEventListener('DOMContentLoaded', function() {
    console.log("DOM حاضیردیر - باشا اسکرول");
    scrollToTop();
});

// علاوه امینلیک اوچون، قیسا بیر گئجیکمه‌دن سونرا یوخلا
setTimeout(scrollToTop, 500);

// اینگیلیسجه سایی تورکجه‌یه چئویرمک
function toPersianNumber(num) {
    if (num === null || num === undefined) return '';
    return num.toString().replace(/\d/g, d => "۰۱۲۳۴۵۶۷۸۹"[d]);
}

// گون آدلاری تورکجه آذربایجانیجا
const dayNamesAzerbaijani = {
    'شنبه': 'یئل‌لی گون',
    'یکشنبه': 'سوت گونو', 
    'دوشنبه': 'دوز گونو',
    'سه‌شنبه': 'آرا گون',
    'چهارشنبه': 'اود گونو',
    'پنجشنبه': 'سو گونو',
    'جمعه': 'آینی گون'
};

// آی آدلاری تورکجه آذربایجانیجا
const monthNamesAzerbaijani = {
    'فروردین': 'آغلارگولر',
    'اردیبهشت': 'گون آی',
    'خرداد': 'قیزاران آی',
    'تیر': 'قورا پیشیرن',
    'مرداد': 'قویروق دوغان',
    'شهریور': 'زومار آیی',
    'مهر': 'خزل آیی',
    'آبان': 'قیرؤو آیی',
    'آذر': 'آذر',
    'دی': 'چیلله',
    'بهمن': 'دوندوران آی',
    'اسفند': 'بایرام آیی'
};

// تورکجه آذربایجانی متن‌لر
const azTexts = {
    searchPlaceholder: "گوگل‌ده آختار...",
    quickSitesTitle: "🌐 سورعتلی سایتلار",
    addSite: "اضافه ائتمک",
    editSites: "دَییشدیرمک",
    weatherTitle: "☁️ هاوا دورومو",
    weatherLoading: "هاوا دورومو یوکله‌نیر...",
    weatherError: "خطا باش وئردی",
    weatherForecast: "گله‌جک گونلرین هاوا دورومو",
    clockTitle: "⏰ ساعات",
    clockLoading: "یوکله‌نیر...",
    dateTitle: "📅 تاریخ",
    dateLoading: "یوکله‌نیر...",
    tasksTitle: "✅ گونده‌لیک تاپشیریقلار",
    taskPlaceholder: "یئنی تاپشیریغینیزی یازین",
    noTasks: "هئچ تاپشیریق یوخدور",
    completeTask: "یئرینه یئتیریلدی",
    uncompleteTask: "یئنیله",
    deleteTask: "سیل",
    currencyTitle: "💱 پارا پول",
    currencyLoading: "پارا پول یوکله‌نیر...",
    currencyError: "پارا پول معلوماتلاری آلینمادی",
    notesTitle: "📒 نوت‌لار",
    notesPlaceholder: "نوت لارینیزی یازین ...",
    lastUpdate: "سون یوکله‌نمه:",
    source: "منبع:",
    tryAgain: "یئنیدن یوکله",
    addNewSite: " ",
    siteName: "سایتین آدی:",
    siteUrl: "سایتین آدرسى:",
    siteIcon: "آیکون (ئیختىيارى):",
    save: "قئيد ائتمک",
    maxSites: "ماکسیموم 6 سایت اضافه ائده بیلرسینیز",
    enterFullUrl: "سایتین تام آدرسی وارد ائدین (http یا https ایله)",
    noSitesAdded: " سایت اضافه ائتممىسینیز",
    currentSites: "حاضیرکی سایتلار:",
    longPressDelete: "سیلمک اوچون اوزون باسین",
    converterTitle: "𐰜𐰇𐰚𐱅𐰇𐰼𐰚𐰲𐰀 ترجومه",
    converterPlaceholder: "لاتین الیفباسی ایله یازین ...",
    converterOutputPlaceholder: "اورخون الیفباسی ایله سونوج ...",
    clearBtn: "تمیزله",
    converterInfo: "𐰜𐰇𐰚𐱅𐰇𐰼𐰚 الفباسی ایله ترجومه"
};

// ====== آختاریش و سورعتلی سایتلارین ایداره‌سی ======
function setupSearch() {
    const searchForm = document.getElementById('searchForm');
    const searchInput = document.getElementById('searchInput');
    
    if (searchForm && searchInput) {
        searchInput.placeholder = azTexts.searchPlaceholder;
        
        searchForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const query = searchInput.value.trim();
            if (query) {
                window.open(`https://www.google.com/search?q=${encodeURIComponent(query)}`, '_self');
                searchInput.value = '';
            }
        });
        
        searchInput.addEventListener('focus', function() {
            this.select();
        });
    }
}

function setupQuickSites() {
    loadSites();
    
    const addSiteBtn = document.getElementById('addSiteBtn');
    const editSitesBtn = document.getElementById('editSitesBtn');
    
    if (addSiteBtn) {
        addSiteBtn.querySelector('.site-name').textContent = azTexts.addSite;
        addSiteBtn.addEventListener('click', openAddSiteModal);
    }
    if (editSitesBtn) {
        editSitesBtn.querySelector('.site-name').textContent = azTexts.editSites;
        editSitesBtn.addEventListener('click', editSites);
    }
    
    const modal = document.getElementById('siteModal');
    const closeBtn = document.querySelector('.close');
    
    if (closeBtn) {
        closeBtn.addEventListener('click', function() {
            if (modal) modal.style.display = 'none';
        });
    }
    
    window.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.style.display = 'none';
        }
    });
    
    const siteForm = document.getElementById('siteForm');
    if (siteForm) {
        siteForm.addEventListener('submit', function(e) {
            e.preventDefault();
            addNewSite();
        });
    }
}

function loadSites() {
    const sites = JSON.parse(localStorage.getItem('quickSites') || '[]');
    const sitesGrid = document.querySelector('.sites-grid');
    
    if (!sitesGrid) return;
    
    const existingSites = sitesGrid.querySelectorAll('.site-item:not(.site-add)');
    existingSites.forEach(site => site.remove());
    
    sites.forEach((site, index) => {
        const siteElement = createSiteElement(site, index);
        const addBtn = document.getElementById('addSiteBtn');
        if (addBtn) {
            sitesGrid.insertBefore(siteElement, addBtn);
        }
    });
}

// سایت فاوآیکونو آلماق
async function fetchFavicon(url) {
    try {
        let domain;
        try {
            domain = new URL(url).hostname;
        } catch (error) {
            domain = url.replace(/https?:\/\//, '').split('/')[0];
        }

        let faviconUrl = `https://www.google.com/s2/favicons?domain=${domain}&sz=64`;

        // گوگل سرویس‌لری اوچون ایستیسنا
        if (domain.includes("mail.google.com")) {
            faviconUrl = "https://ssl.gstatic.com/ui/v1/icons/mail/rfr/gmail.ico";
        } else if (domain.includes("drive.google.com")) {
            faviconUrl = "https://ssl.gstatic.com/docs/doclist/images/drive_2022q3_32dp.png";
        } else if (domain.includes("calendar.google.com")) {
            faviconUrl = "https://calendar.google.com/googlecalendar/images/favicons_2020q4/calendar_31.ico";
        } else if (domain.includes("docs.google.com")) {
            faviconUrl = "https://ssl.gstatic.com/docs/documents/images/kix-favicon7.ico";
        } else if (domain.includes("sheets.google.com")) {
            faviconUrl = "https://ssl.gstatic.com/docs/spreadsheets/images/drive_spreadsheet_2020q4.ico";
        } else if (domain.includes("slides.google.com")) {
            faviconUrl = "https://ssl.gstatic.com/docs/presentations/images/drive_presentation_2020q4.ico";
        }

        return new Promise((resolve) => {
            const img = new Image();
            img.onload = function() {
                resolve(`<img src="${faviconUrl}" alt="favicon" class="site-favicon">`);
            };
            img.onerror = function() {
                resolve('🌐');
            };
            img.src = faviconUrl;
        });

    } catch (error) {
        console.error('فاوآیکون آلماقدا خطا:', error);
        return '🌐';
    }
}

function createSiteElement(site, index) {
    const div = document.createElement('div');
    div.className = 'site-item';
    
    const iconContent = site.icon.startsWith('<img') ? 
        site.icon : 
        `<div class="site-icon">${site.icon}</div>`;
    
    div.innerHTML = `
        ${iconContent}
        <span class="site-name">${site.name}</span>
    `;
    
    div.addEventListener('click', function() {
        window.open(site.url, '_self');
    });
    
    let longPressTimer;
    div.addEventListener('mousedown', function() {
        longPressTimer = setTimeout(() => {
            if (confirm(`"${site.name}" سیلینسینمی؟`)) {
                removeSite(index);
            }
        }, 1000);
    });
    
    div.addEventListener('mouseup', function() {
        clearTimeout(longPressTimer);
    });
    
    div.addEventListener('mouseleave', function() {
        clearTimeout(longPressTimer);
    });
    
    return div;
}

function openAddSiteModal() {
    const modal = document.getElementById('siteModal');
    const form = document.getElementById('siteForm');
    if (modal && form) {
        const modalTitle = modal.querySelector('h3');
        const labels = modal.querySelectorAll('label');
        const button = modal.querySelector('button');
        
        if (modalTitle) modalTitle.textContent = azTexts.addNewSite;
        if (labels[0]) labels[0].textContent = azTexts.siteName;
        if (labels[1]) labels[1].textContent = azTexts.siteUrl;
        if (labels[2]) labels[2].textContent = azTexts.siteIcon;
        if (button) button.textContent = azTexts.save;
        
        form.reset();
        modal.style.display = 'block';
    }
}

async function addNewSite() {
    const nameInput = document.getElementById('siteName');
    const urlInput = document.getElementById('siteUrl');
    const iconInput = document.getElementById('siteIcon');
    
    if (!nameInput || !urlInput) return;
    
    const name = nameInput.value.trim();
    const url = urlInput.value.trim();
    let icon = iconInput ? iconInput.value.trim() : '🌐';
    
    if (!name || !url) return;
    
    if (!url.startsWith('http')) {
        alert(azTexts.enterFullUrl);
        return;
    }
    
    const sites = JSON.parse(localStorage.getItem('quickSites') || '[]');
    
    if (sites.length >= 6) {
        alert(azTexts.maxSites);
        return;
    }
    
    if (!icon || icon === '🌐') {
        try {
            icon = await fetchFavicon(url);
        } catch (error) {
            console.error('فاوآیکون آلماقدا خطا:', error);
            icon = '🌐';
        }
    }
    
    sites.push({ name, url, icon });
    localStorage.setItem('quickSites', JSON.stringify(sites));
    
    const modal = document.getElementById('siteModal');
    if (modal) modal.style.display = 'none';
    
    loadSites();
}

function removeSite(index) {
    const sites = JSON.parse(localStorage.getItem('quickSites') || '[]');
    sites.splice(index, 1);
    localStorage.setItem('quickSites', JSON.stringify(sites));
    loadSites();
}

function editSites() {
    const sites = JSON.parse(localStorage.getItem('quickSites') || '[]');
    if (sites.length === 0) {
        alert(azTexts.noSitesAdded);
        return;
    }
    
    let message = azTexts.currentSites + '\n\n';
    sites.forEach((site, index) => {
        message += `${index + 1}. ${site.name} - ${site.url}\n`;
    });
    message += `\n${azTexts.longPressDelete}`;
    
    alert(message);
}

// ====== تاریخ و ساعات ویجتی ======
let clockInterval;

function updateClock() {
    try {
        const clockElement = document.getElementById("clock");
        if (!clockElement) return;
        
        const now = new Date();
        
        // آذربایجان واختی (Asia/Tabriz timezone)
        const azTime = now.toLocaleTimeString("fa-IR", { 
            timeZone: 'Asia/Tehran',
            hour: '2-digit', 
            minute: '2-digit'
        });
        
        const clockTimeElement = clockElement.querySelector('.clock-time');
        if (clockTimeElement) {
            clockTimeElement.textContent = azTime;
        }
        
    } catch (error) {
        console.error("ساعات یوکله‌نمه‌سینده خطا:", error);
        
        // Fallback
        const clockElement = document.getElementById("clock");
        if (clockElement) {
            const now = new Date();
            const time = now.toLocaleTimeString("fa-IR", { 
                hour: '2-digit', 
                minute: '2-digit'
            });
            
            const clockTimeElement = clockElement.querySelector('.clock-time');
            if (clockTimeElement) {
                clockTimeElement.textContent = time;
            }
        }
    }
}

function updateDateDisplay() {
    try {
        const dateElement = document.getElementById("dateDisplay");
        if (!dateElement) return;
        
        const now = new Date();
        const dayNameFa = now.toLocaleDateString('fa-IR', { weekday: 'long' });
        const dayNameAz = dayNamesAzerbaijani[dayNameFa] || dayNameFa;
        
        const monthNameFa = now.toLocaleDateString('fa-IR', { month: 'long' });
        const monthNameAz = monthNamesAzerbaijani[monthNameFa] || monthNameFa;
        
        const shamsiDay = now.toLocaleDateString('fa-IR', {
            day: 'numeric',
            calendar: 'persian'
        });
        
        const persianDateNumeric = now.toLocaleDateString('fa-IR', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit'
        });
        
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const day = String(now.getDate()).padStart(2, '0');
        const gregorianDate = `${year}/${month}/${day}`;
        
        dateElement.innerHTML = `
            <div class="date-item">${monthNameAz} (${monthNameFa})</div>
            <div class="date-day-number">${shamsiDay}</div>
            <div class="date-item">${dayNameAz} (${dayNameFa})</div>
            <div class="date-info">${persianDateNumeric} | ${gregorianDate}</div>
        `;
    } catch (error) {
        console.error("تاریخ یوکله‌نمه‌سینده خطا:", error);
    }
}

function startClock() {
    updateClock();
    updateDateDisplay();
    clockInterval = setInterval(updateClock, 1000);
}

// ====== هاوا دورومو ======
const weatherCache = new Map();
const CACHE_DURATION = 10 * 60 * 1000;
const cities = ["Tabriz", "Tehran", "Urmia", "Ardabil", "Zanjan", "Qazvin", "Khoy", "Maragheh"];

const weatherIcons = {
    "Sunny": "☀️", 
    "Clear": getClearIcon, // اؤزوندن تشخیص اوچون تابع ایستیفاده
    "Partly cloudy": "⛅", 
    "Cloudy": "☁️",
    "Overcast": "🌥️", 
    "Mist": "🌫️", 
    "Patchy rain possible": "🌦️",
    "Light rain": "🌧️", 
    "Heavy rain": "⛈️", 
    "Snow": "❄️", 
    "Thunderstorm": "🌩️"
};

// "Clear" وضعیتی اوچون مناسب ایموجی تشخیصی
function getClearIcon() {
    const hour = new Date().getHours();
    // اگه ساعات ۶ صبحدن ۶ آخشاما قدر اولسا، گونش گؤستریلسین
    return (hour >= 6 && hour < 18) ? "☀️" : "🌙";
}

// ایموجی آلماق اوچون کؤمک تابعی
function getWeatherIcon(weatherDesc) {
    const icon = weatherIcons[weatherDesc];
    
    // اگه icon بیر تابع اولسا، اجرا ائت
    if (typeof icon === 'function') {
        return icon();
    }
    
    // یوخسا مستقیم قیمتی قایتار
    return icon || "☁️";
}

async function fetchWithTimeout(url, timeout = 8000) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeout);
    
    try {
        const response = await fetch(url, { 
            signal: controller.signal,
            mode: 'cors',
            headers: {
                'User-Agent': 'Mozilla/5.0 (compatible; NewTabExtension/1.0)',
                'Accept': 'application/json'
            }
        });
        clearTimeout(timeoutId);
        
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        return await response.json();
    } catch (error) {
        clearTimeout(timeoutId);
        if (error.name === 'AbortError') throw new Error('سورعت ایسته‌گی زمان آشیب');
        throw error;
    }
}

async function fetchCityWeather(city) {
    const cacheKey = city.toLowerCase();
    const cached = weatherCache.get(cacheKey);
    
    if (cached && (Date.now() - cached.timestamp < CACHE_DURATION)) {
        return cached.data;
    }
    
    try {
        const url = `https://wttr.in/${encodeURIComponent(city)}?format=j1`;
        const data = await fetchWithTimeout(url);
        
        weatherCache.set(cacheKey, { data: data, timestamp: Date.now() });
        return data;
    } catch (error) {
        console.error(`${city} اوچون هاوا دورومو آلینمادی:`, error);
        throw error;
    }
}

async function fetchAndDisplay4DayForecast(cityName, forecastListElement) {
    try {
        forecastListElement.innerHTML = '<div class="weather-loading">یوکله‌نیر...</div>';
        
        const data = await fetchCityWeather(cityName);

        if (data.weather && data.weather.length > 0) {
            let forecastHtml = '';
            
            for (let i = 1; i < Math.min(data.weather.length, 4); i++) {
                const dayData = data.weather[i];
                const date = new Date(dayData.date);
                const dayNameFa = date.toLocaleDateString('fa-IR', { weekday: 'long' });
                const dayNameAz = dayNamesAzerbaijani[dayNameFa] || dayNameFa;
                
                const temp = `° ${toPersianNumber(dayData.maxtempC)} ▲️ | ▼ ° ${toPersianNumber(dayData.mintempC)}`;

                forecastHtml += `
                    <div class="forecast-day">
                        <span class="day-name">${dayNameAz}</span>: <span class="day-temp">${temp}</span>
                    </div>
                `;
            }
            
            forecastListElement.innerHTML = forecastHtml;
        } else {
            forecastListElement.innerHTML = '<p>هاوا دورومو معلوماتلاری مؤوجود دئییل.</p>';
        }
    } catch (error) {
        console.error(`${cityName}: اوچون هاوا دورومونو الده ائدرکه‌ن خطا باش وئردی `, error);
        forecastListElement.innerHTML = '<p>خطا باش وئردی</p>';
    }
}

async function loadWeather() {
    const container = document.getElementById("weather");
    if (!container) return;
    
    const weatherTitle = document.querySelector('.weather h3');
    if (weatherTitle) weatherTitle.textContent = azTexts.weatherTitle;
    
    container.innerHTML = `<div class="weather-loading">${azTexts.weatherLoading}</div>`;
    
    let html = '';
    const nameMap = { 
        'Tabriz': 'تبریز', 'Tehran': 'تهران', 'Urmia': 'اورمو', 'Ardabil': 'اردبیل',
        'Zanjan': 'زنگان', 'Qazvin': 'قزوین', 'Khoy': 'خوی', 'Maragheh': 'ماراغا' 
    };

    try {
        for (let c of cities) {
            try {
                const data = await fetchCityWeather(c);
                const curr = data.current_condition && data.current_condition[0];
                const temp = curr ? `${toPersianNumber(curr.temp_C)}°` : '—';
                const desc = curr && curr.weatherDesc && curr.weatherDesc[0] ? curr.weatherDesc[0].value : '';
                const icon = getWeatherIcon(desc);
                const displayName = nameMap[c] || c;

                html += `
                    <div class="city-line" data-city="${c}">
                        <div class="city-name">
                            <table>
                                <tr>
                                    <th>${displayName}</th>
                                    <th>${icon}</th>
                                    <th>${temp}</th>
                                </tr>
                            </table>
                        </div>
                        <div class="city-forecast-details" style="display: none;">
                            <p>${azTexts.weatherForecast}</p>
                            <div class="forecast-list"></div>
                        </div>
                    </div>
                `;
            } catch (e) {
                const displayName = nameMap[c] || c;
                html += `
                    <div class="city-line">
                        <div class="city-name">${displayName}</div>
                        <div class="city-temp">⚠️ ${azTexts.weatherError}</div>
                    </div>
                `;
            }
        }
        
        // یئنیله‌نمه معلوماتلاری آرتیرماق
        html += `
            <div style="text-align: center; margin-top: 15px; padding: 7px; color: #ffffffb8;
                       background: rgba(0,0,0,0.05); border-radius: 8px; font-size: 14px;">
                <div>${azTexts.lastUpdate} ${toPersianNumber(new Date().toLocaleTimeString('fa-IR'))}</div>
            </div>
        `;
        
        // یالنیز بیر دفعه innerHTML-ی ست ائتمک
        container.innerHTML = html;
        
        // event listenerلاری آرتیرماق
        addCityClickListeners();
        
    } catch (error) {
        console.error("هاوا دورومو یوکله‌نمه‌سینده خطا:", error);
        container.innerHTML = `<div class="weather-loading">${azTexts.weatherError}</div>`;
    }
}

function addCityClickListeners() {
    const cityLines = document.querySelectorAll('.city-line');
    
    cityLines.forEach(cityLine => {
        const forecastDetails = cityLine.querySelector('.city-forecast-details');
        const cityName = cityLine.getAttribute('data-city');

        if (forecastDetails && cityName) {
            cityLine.addEventListener('click', (event) => {
                event.stopPropagation(); // event bubbling-ین قاباغینی آلماق
                
                // باخماق کی بو کرکه حاضیردا آچیق اولسون می؟
                const isCurrentlyOpen = forecastDetails.style.display === 'block';
                
                // ایلک اول همه کرکه‌لری باغلا
                closeAllWeatherForecasts();
                
                // اگه بو کرکه قبلاً آچیق اولماسا ایندی آچ
                if (!isCurrentlyOpen) {
                    forecastDetails.style.display = 'block';
                    cityLine.classList.add('active');
                    
                    // اگه محتوی بوش اولسا، معلوماتلاری یوکله
                    if (forecastDetails.querySelector('.forecast-list').innerHTML === '') {
                        fetchAndDisplay4DayForecast(cityName, forecastDetails.querySelector('.forecast-list'));
                    }
                }
            });
        }
    });
    
    // کرکه‌لرین خاریجینده کلیک‌ده handle ائتمک
    document.addEventListener('click', (event) => {
        if (!event.target.closest('.city-line')) {
            closeAllWeatherForecasts();
        }
    });
}

function closeAllWeatherForecasts() {
    const cityLines = document.querySelectorAll('.city-line');
    const forecastDetails = document.querySelectorAll('.city-forecast-details');
    
    cityLines.forEach(line => {
        line.classList.remove('active');
    });
    
    forecastDetails.forEach(detail => {
        detail.style.display = 'none';
    });
}

// ====== تاپشیریقلارین ایداره‌سی ======
function loadTasks() {
    const taskList = document.getElementById("taskList");
    if (!taskList) return;
    
    const tasksTitle = document.querySelector('.tasks h3');
    const taskInput = document.getElementById('taskInput');
    if (tasksTitle) tasksTitle.textContent = azTexts.tasksTitle;
    if (taskInput) taskInput.placeholder = azTexts.taskPlaceholder;
    
    const tasks = JSON.parse(localStorage.getItem('tasks') || '[]');
    taskList.innerHTML = '';
    
    if (tasks.length === 0) {
        taskList.innerHTML = `<div style="text-align: center; padding: 20px; opacity: 0.7;">${azTexts.noTasks}</div>`;
        return;
    }
    
    tasks.forEach((task, index) => {
        const li = document.createElement('li');
        
        const taskContainer = document.createElement('div');
        taskContainer.className = 'task-container';
        
        const taskText = document.createElement('span');
        taskText.textContent = task.text;
        taskText.className = 'task-text';
        if (task.completed) taskText.classList.add('completed');
        
        const iconsContainer = document.createElement('div');
        iconsContainer.className = 'task-icons';
        
        const completeIcon = document.createElement('span');
        completeIcon.innerHTML = task.completed ? '✅' : '🟩';
        completeIcon.className = 'task-icon';
        completeIcon.title = task.completed ? azTexts.uncompleteTask : azTexts.completeTask;
        completeIcon.addEventListener('click', (e) => {
            e.stopPropagation();
            toggleTaskCompletion(index);
        });
        
        const deleteIcon = document.createElement('span');
        deleteIcon.innerHTML = '❌';
        deleteIcon.className = 'task-icon';
        deleteIcon.title = azTexts.deleteTask;
        deleteIcon.addEventListener('click', (e) => {
            e.stopPropagation();
            removeTask(index);
        });
        
        iconsContainer.appendChild(completeIcon);
        iconsContainer.appendChild(deleteIcon);
        taskContainer.appendChild(taskText);
        taskContainer.appendChild(iconsContainer);
        li.appendChild(taskContainer);
        taskList.appendChild(li);
        
        li.addEventListener('click', (e) => {
            if (e.target !== completeIcon && e.target !== deleteIcon) {
                toggleTaskCompletion(index);
            }
        });
    });
}

function saveTasks(tasks) {
    localStorage.setItem('tasks', JSON.stringify(tasks));
}

function addTask() {
    const taskInput = document.getElementById("taskInput");
    if (!taskInput) return;
    
    const taskText = taskInput.value.trim();
    if (!taskText) return;
    
    const tasks = JSON.parse(localStorage.getItem('tasks') || '[]');
    tasks.push({ text: taskText, completed: false, createdAt: new Date().toISOString() });
    
    saveTasks(tasks);
    loadTasks();
    taskInput.value = '';
    taskInput.focus();
}

function removeTask(index) {
    const tasks = JSON.parse(localStorage.getItem('tasks') || '[]');
    tasks.splice(index, 1);
    saveTasks(tasks);
    loadTasks();
}

function toggleTaskCompletion(index) {
    const tasks = JSON.parse(localStorage.getItem('tasks') || '[]');
    tasks[index].completed = !tasks[index].completed;
    saveTasks(tasks);
    loadTasks();
}

// ====== نوت‌لارین ایداره‌سی ======
function setupNoteArea() {
    const noteArea = document.getElementById('noteArea');
    const notesTitle = document.querySelector('.notes h3');
    
    if (notesTitle) notesTitle.textContent = azTexts.notesTitle;
    if (noteArea) {
        noteArea.placeholder = azTexts.notesPlaceholder;
        
        const savedNote = localStorage.getItem('note');
        if (savedNote) noteArea.value = savedNote;
        
        noteArea.addEventListener('input', () => {
            localStorage.setItem('note', noteArea.value);
        });
    }
}

// ====== پارا پول ویجتی ======
const CURRENCY_API_URL = 'https://BrsApi.ir/Api/Market/Gold_Currency.php?key=B4WihCKeRpj9KMiHgGfQ3gRTwwVu9YUy';

async function fetchCurrencyRates() {
    try {
        const response = await fetch(CURRENCY_API_URL, {
            method: 'GET',
            mode: 'cors',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        return await response.json();
    } catch (error) {
        console.error("پارا پول آلینمادی:", error);
        return {
            currency: [
                { name: 'دلار آمریکا', price: '50000', change_percent: 1.2 },
                { name: 'یورو', price: '55000', change_percent: -0.5 },
                { name: 'لیر ترکیه', price: '1600', change_percent: 1.5 },
                { name: 'منات آذربایجان', price: '30500', change_percent: 0.8 }
            ]
        };
    }
}

function extractCurrencyPrices(data) {
    const prices = {};
    
    if (data?.currency?.length) {
        data.currency.forEach(item => {
            if (!item || !item.name) return;
            
            const name = String(item.name).toLowerCase();
            const priceValue = item.price;
            const changeValue = item.change_percent;
            
            if (priceValue && !isNaN(priceValue)) {
                if (name.includes('دلار') && !name.includes('تتر') && !name.includes('کانادا') && !name.includes('استرالیا')) {
                    prices.dollar = { 
                        price: parseInt(priceValue), 
                        change: parseFloat(changeValue) || 0
                    };
                }
                else if (name.includes('یورو')) {
                    prices.euro = { 
                        price: parseInt(priceValue), 
                        change: parseFloat(changeValue) || 0
                    };
                }
                else if (name.includes('لیر') && name.includes('ترکیه')) {
                    prices.lira = { 
                        price: parseInt(priceValue), 
                        change: parseFloat(changeValue) || 0
                    };
                }
                else if (name.includes('منات') && name.includes('آذربایجان')) {
                    prices.manat = { 
                        price: parseInt(priceValue), 
                        change: parseFloat(changeValue) || 0
                    };
                }
            }
        });
    }
    
    if (!prices.dollar) prices.dollar = { price: 50000, change: 1.2 };
    if (!prices.euro) prices.euro = { price: 55000, change: -0.5 };
    if (!prices.lira) prices.lira = { price: 1600, change: 1.5 };
    if (!prices.manat) prices.manat = { price: 30500, change: 0.8 };
    
    return prices;
}

async function loadCurrencyRates() {
    const container = document.getElementById("currencyRates");
    if (!container) return;
    
    const currencyTitle = document.querySelector('.currency h3');
    if (currencyTitle) currencyTitle.textContent = azTexts.currencyTitle;
    
    container.innerHTML = `<div class="weather-loading">${azTexts.currencyLoading}</div>`;
    
    try {
        const data = await fetchCurrencyRates();
        const prices = extractCurrencyPrices(data);
        
        let html = '';
        const currencies = [
            { key: 'dollar', name: 'آمریکا دولاری', emoji: '💵', flag: '🇺🇸' },
            { key: 'euro', name: 'یورو', emoji: '💶', flag: '🇪🇺' },
            { key: 'lira', name: 'تورک لیره‌سی', emoji: '💷', flag: '🇹🇷' },
            { key: 'manat', name: 'آذربایجان ماناتی', emoji: '🏦', flag: '🇦🇿' }
        ];
        
        currencies.forEach(currency => {
            const rate = prices[currency.key];
            
            if (rate && rate.price && rate.price > 0) {
                const formattedPrice = toPersianNumber(rate.price.toLocaleString('fa-IR'));
                const change = rate.change || 0;
                const changeClass = change >= 0 ? 'positive' : 'negative';
                const changeIcon = change >= 0 ? '📈' : '📉';
                
                html += `
                    <div class="currency-rate">
                        <span class="currency-name">${currency.name} ${currency.emoji}</span>
                        <div>
                            <span class="currency-price">${formattedPrice} تومن</span>
                            
                        </div>
                    </div>
                `;
            }
        });
        
        html += `
            <div style="text-align: center; margin-top: 15px; padding: 7px;     color: #ffffffb8;
                       background: rgba(0,0,0,0.05); border-radius: 8px; font-size: 14px;">
                <div>${azTexts.lastUpdate} ${toPersianNumber(new Date().toLocaleTimeString('fa-IR'))}</div>
            </div>
        `;
        
        container.innerHTML = html;
        
    } catch (error) {
        console.error("پارا پول یوکله‌نمه‌سینده خطا:", error);
        container.innerHTML = `<div class="weather-loading">${azTexts.currencyError}</div>`;
    }
}

// ====== اساس پروگرامین باشلانماسی ======
function initializeApp() {
    console.log("🌞 گونشفای یوکله‌نیر...");
    
    // اساس بولگه‌لر
    startClock();
    loadWeather();
    loadCurrencyRates();
    loadTasks();
    setupNoteArea();
    
    // یئنی بولگه‌لر
    setupSearch();
    setupQuickSites();
    setupOrkhonConverter(); // اورخون چئویریچی‌سینین ایستفاده‌سی
    
    // اؤزوندن یئنیله‌نمه
    setInterval(loadWeather, 5 * 60 * 1000);
    setInterval(loadCurrencyRates, 5 * 60 * 1000);
    
    // تاپشیریقلارین ایداره‌سی
    const addTaskBtn = document.getElementById("addTask");
    const taskInput = document.getElementById("taskInput");
    
    if (addTaskBtn && taskInput) {
        addTaskBtn.addEventListener('click', addTask);
        taskInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') addTask();
        });
    }
    
    console.log("✅ گونشفای اوغرورلا یوکلندی");
}

// پروگرامی چالیشدیر
document.addEventListener('DOMContentLoaded', initializeApp);

// خطالارین ایداره‌سی
window.addEventListener('error', function(e) {
    console.error('خطا:', e.error);
});

window.addEventListener('unhandledrejection', function(e) {
    console.error('Promise رد اولوندو:', e.reason);
});

// ====== اورخون الیفبا چئویریچیسی ======
const orkhonConverter = {
    // تام اوخشاش turkbitig.com کیمی واکه نقشه‌لری
    backVowelMap: {
        'ab': '𐰀𐰉', 'ba': '𐰉𐰀', 'ıb': '𐰃𐰉', 'bı': '𐰉𐰃', 'ob': '𐰆𐰉', 'bo': '𐰉𐰆',    
        'ad': '𐰀𐰑', 'da': '𐰑𐰀', 'ıd': '𐰃𐰑', 'dı': '𐰑𐰃', 'od': '𐰆𐰑', 'do': '𐰑𐰆',
        'ag': '𐰀𐰍', 'ga': '𐰍𐰀', 'ıg': '𐰃𐰍', 'gı': '𐰍𐰃', 'og': '𐰆𐰍', 'go': '𐰍𐰆',    
        'ak': '𐰀𐰴', 'ka': '𐰴𐰀', 'ık': '𐰶', 'kı': '𐰶𐰃', 'ok': '𐰸', 'ko': '𐰸𐰆',   
        'al': '𐰀𐰞', 'la': '𐰞𐰀', 'ıl': '𐰃𐰞', 'lı': '𐰞𐰃', 'ol': '𐰆𐰞', 'lo': '𐰞𐰆',  
        'an': '𐰀𐰣', 'na': '𐰣𐰀', 'ın': '𐰃𐰣', 'nı': '𐰣𐰃', 'on': '𐰆𐰣', 'no': '𐰣𐰆',
        'ar': '𐰀𐰺', 'ra': '𐰺𐰀', 'ır': '𐰃𐰺', 'rı': '𐰺𐰃', 'or': '𐰆𐰺', 'ro': '𐰺𐰆', 
        'as': '𐰀𐰽', 'sa': '𐰽𐰀', 'ıs': '𐰃𐰽', 'sı': '𐰽𐰃', 'os': '𐰆𐰽', 'so': '𐰽𐰆',
        'at': '𐰀𐱃', 'ta': '𐱃𐰀', 'ıt': '𐰃𐱃', 'tı': '𐱃𐰃', 'ot': '𐰆𐱃', 'to': '𐱃𐰆',
        'ay': '𐰀𐰖', 'ya': '𐰖𐰀', 'ıy': '𐰃𐰖', 'yı': '𐰖𐰃', 'oy': '𐰆𐰖', 'yo': '𐰖𐰆',
        'a': '𐰀', 'ı': '𐰃', 'o': '𐰆',
        'b': '𐰉', 'd': '𐰑', 'g': '𐰍', 'k': '𐰴', 'l': '𐰞', 'n': '𐰣', 'r': '𐰺', 's': '𐰽', 't': '𐱃', 'y': '𐰖',
        'ç': '𐰲', 'm': '𐰢', 'ñ': '𐰭', 'p': '𐰯', 'ş': '𐱁', 'z': '𐰔'
    },

    frontVowelMap: {
        'eb': '𐰀𐰋', 'be': '𐰋𐰀', 'ib': '𐰃𐰋', 'bi': '𐰋𐰃', 'öb': '𐰇𐰋', 'bö': '𐰋𐰇',    
        'ed': '𐰀𐰓', 'de': '𐰓𐰀', 'id': '𐰃𐰓', 'di': '𐰓𐰃', 'öd': '𐰇𐰓', 'dö': '𐰓𐰇',
        'eg': '𐰀𐰏', 'ge': '𐰏𐰀', 'ig': '𐰃𐰏', 'gi': '𐰏𐰃', 'ög': '𐰇𐰏', 'gö': '𐰏𐰇',    
        'ek': '𐰀𐰚', 'ke': '𐰚𐰀', 'ik': '𐰃𐰚', 'ki': '𐰚𐰃', 'ök': '𐰇𐰜',  'kö': '𐰚𐰇',
        'el': '𐰀𐰠', 'le': '𐰠𐰀', 'il': '𐰃𐰠', 'li': '𐰠𐰃', 'öl': '𐰇𐰠', 'lö': '𐰠𐰇',    
        'en': '𐰀𐰤', 'ne': '𐰤𐰀', 'in': '𐰃𐰤', 'ni': '𐰤𐰃', 'ön': '𐰇𐰤', 'nö': '𐰤𐰇',    
        'er': '𐰀𐰼', 're': '𐰼𐰀', 'ir': '𐰃𐰼', 'ri': '𐰼𐰃', 'ör': '𐰇𐰼', 'rö': '𐰼𐰇',    
        'es': '𐰀𐰾', 'se': '𐰾𐰀', 'is': '𐰃𐰾', 'si': '𐰾𐰃', 'ös': '𐰇𐰾', 'sö': '𐰾𐰇',
        'et': '𐰀𐱅', 'te': '𐱅𐰀', 'it': '𐰃𐱅', 'ti': '𐱅𐰃', 'öt': '𐰇𐱅', 'tö': '𐱅𐰇',   
        'ey': '𐰀𐰘', 'ye': '𐰘𐰀', 'iy': '𐰃𐰘', 'yi': '𐰘𐰃', 'öy': '𐰇𐰘', 'yö': '𐰘𐰇',
        'e': '𐰀', 'i': '𐰃', 'ö': '𐰇',    
        'b': '𐰋', 'd': '𐰓', 'g': '𐰏', 'k': '𐰚', 'l': '𐰠', 'n': '𐰤', 'r': '𐰼', 's': '𐰾', 't': '𐱅', 'y': '𐰘',
        'ç': '𐰲', 'm': '𐰢', 'ñ': '𐰭', 'p': '𐰯', 'ş': '𐱁', 'z': '𐰔',
    },

    vowels: new Set(['a', 'e', 'ı', 'i', 'o', 'ö', 'u', 'ü']),

    // لاتین‌دن اورخونا چئویرمه اوچون اؤن پردازش
    replacementsLatinToOrkhon: {
        'Ä': 'e', 'ä': 'e', 'Ə': 'e', 'ə': 'e',
        'İ': 'i', 'I': 'ı',
        'h': 'k', 'H': 'k', 'X': 'k', 'x': 'k', 'Q': 'k', 'q': 'k',
        'C': 'ç', 'c': 'ç', 'J': 'ç', 'j': 'ç',
        'ğ': 'g', 'Ğ': 'g',
        'f': 'p', 'F': 'p',
        'v': 'b', 'V': 'b', 'W': 'b', 'w': 'b',
        'U': 'o', 'u': 'o',
        'Ū': 'o', 'ū': 'o',
        'Ü': 'ö', 'ü': 'ö', // اورخونا چئویرمه اوچون: ü به ö
        'Ý': 'y', 'ý': 'y',
    },

    preprocessInput(input, direction) {
        if (direction === 'latin-to-orkhon') {
            return input.replace(/./g, char => this.replacementsLatinToOrkhon[char] || char);
        } else {
            return input; // معکوس چئویرمه اوچون، اؤن پردازش لازیم دئییل
        }
    },

    // لاتین‌دن اورخونا چئویرمه تابعی (تام اوخشاش turkbitig.com)
    convertToOldTurkic(input) {
        let processedInput = this.preprocessInput(input, 'latin-to-orkhon');
        let result = '';
        let i = 0;
        let currentMap = this.backVowelMap;
        let isNewWord = true;

        while (i < processedInput.length) {
            const ch = processedInput[i];

            // یئنی سؤز اوچون بوشلوقلاری handle ائتمک
            if (/\s/.test(ch)) {
                result += ch;
                isNewWord = true;
                i++;
                continue;
            }

            // باشلاندا currentMap-ی backVowelMap-ه ست ائتمک
            if (isNewWord) {
                currentMap = this.backVowelMap;
                isNewWord = false;
            }

            let foundPair = false;

            // هجّه تشکیل‌ده‌ن جوتلری یوخلاماق
            if (i + 1 < processedInput.length) {
                const first = processedInput[i].toLowerCase();
                const second = processedInput[i + 1].toLowerCase();
                const pair1 = first + second;
                const pair2 = second + first;

                if (this.backVowelMap.hasOwnProperty(pair1)) {
                    result += this.backVowelMap[pair1];
                    currentMap = this.backVowelMap;
                    i += 2;
                    foundPair = true;
                } else if (this.frontVowelMap.hasOwnProperty(pair1)) {
                    result += this.frontVowelMap[pair1];
                    currentMap = this.frontVowelMap;
                    i += 2;
                    foundPair = true;
                } else if (this.backVowelMap.hasOwnProperty(pair2)) {
                    result += this.backVowelMap[pair2];
                    currentMap = this.backVowelMap;
                    i += 2;
                    foundPair = true;
                } else if (this.frontVowelMap.hasOwnProperty(pair2)) {
                    result += this.frontVowelMap[pair2];
                    currentMap = this.frontVowelMap;
                    i += 2;
                    foundPair = true;
                }
            }

            if (!foundPair) {
                // تک کاراکتری پردازش ائتمک
                const singleChar = processedInput[i].toLowerCase();
                if (this.vowels.has(singleChar)) {
                    // تک واکه بیر هجّه تشکیل وئریر
                    if (this.backVowelMap.hasOwnProperty(singleChar)) {
                        result += this.backVowelMap[singleChar];
                        currentMap = this.backVowelMap;
                    } else if (this.frontVowelMap.hasOwnProperty(singleChar)) {
                        result += this.frontVowelMap[singleChar];
                        currentMap = this.frontVowelMap;
                    } else {
                        result += processedInput[i];
                    }
                } else {
                    // تک صامت هجّه‌سی
                    if (currentMap.hasOwnProperty(singleChar)) {
                        result += currentMap[singleChar];
                    } else {
                        result += processedInput[i];
                    }
                }
                i++;
            }
        }

        // اؤزل حاللار - تام اوخشاش اصلی کد کیمی
        result = result.replace(/[𐰤𐰣][𐰓𐰑𐱃𐱅]/gu, '𐰦');
        result = result.replace(/[𐰞𐰠][𐰓𐰑𐱃𐱅]/gu, '𐰡');
        result = result.replace(/[𐰤𐰣]𐰲/gu, '𐰨');
        result = result.replace(/[𐰤𐰣]𐰖/gu, '𐰪');
        result = result.replace(/𐰇[𐰚𐰜]/gu, '𐰜');
        result = result.replace(/𐰃𐰴/gu, '𐰶');
        result = result.replace(/𐰆𐰴/gu, '𐰸');

        result = result.replace(/(?<=\S𐰀|𐰀\S)𐰀(?=[^\s\x00-\x7F])/gu, '');
        result = result.replace(/(?<=\S𐰆|𐰆\S)𐰆(?=\S)/gu, '');
        result = result.replace(/(?<=\S𐰃|𐰃\S)𐰃(?=\S)/gu, '');
        result = result.replace(/(?<=\S𐰇|𐰇\S)𐰇(?=\S)/gu, '');

        result = result.replace(/𐰀𐱃𐱃𐰇𐰼𐰚/g, '𐰀𐱃𐰀𐱅𐰇𐰼𐰜');
        result = result.replace(/𐱅𐰼𐰚/g, '𐱅𐰇𐰼𐰜');
        result = result.replace(/𐱅𐰀𐰭𐰼𐰃/g, '𐱅𐰭𐰼𐰃');
        result = result.replace(/𐱃𐰀𐰣𐰺𐰃/g, '𐱅𐰭𐰼𐰃');
        result = result.replace(/[𐱅𐱃]𐰇𐰼[𐰴𐰚𐰶𐰸]/gu, '𐱅𐰇𐰼𐰜');

        return result;
    },

    // اورخوندان لاتینه چئویرمه (türk یئرینه törk تولید ائتممک اوچون دوزلدی)
    convertToLatin(orkhonText) {
        if (!orkhonText) return '';
        
        let result = orkhonText;
        
        // ایلک اؤزل ترکیبلر و آنا سؤزلری قایتار
        const specialCombinations = {
            '𐰀𐰔𐰼𐰉𐰀𐰖𐰲𐰀𐰣': 'AZƏRBAYCAN',  // دوزلتمه: türk-ه نه törk-ه
            '𐱅𐰇𐰼𐰜': 'türk',  // دوزلتمه: türk-ه نه törk-ه
            '𐰦': 'nt', '𐰡': 'lt', '𐰨': 'nç', '𐰪': 'ny',
            '𐰜': 'k', '𐰶': 'k', '𐰸': 'k'
        };
        
        for (const [orkhon, latin] of Object.entries(specialCombinations)) {
            result = result.replace(new RegExp(orkhon, 'g'), latin);
        }
        
        // تک کاراکترلری چئویرمه 𐰇-نی ü-یه دوزلتمک
        const reverseMap = {
            '𐰀': 'a', '𐰃': 'ı', '𐰆': 'o', '𐰇': 'ü', // دوزلتمه: 𐰇-دن ü-یه نه ö-یه
            '𐰉': 'b', '𐰋': 'b', '𐰑': 'd', '𐰓': 'd',
            '𐰍': 'g', '𐰏': 'g', '𐰴': 'k', '𐰚': 'k',
            '𐰞': 'l', '𐰠': 'l', '𐰣': 'n', '𐰤': 'n',
            '𐰺': 'r', '𐰼': 'r', '𐰽': 's', '𐰾': 's',
            '𐱃': 't', '𐱅': 't', '𐰖': 'y', '𐰘': 'y',
            '𐰲': 'ç', '𐰢': 'm', '𐰭': 'ñ', '𐰯': 'p',
            '𐱁': 'ş', '𐰔': 'z', '𐰕': 'z',
            ' ': ' ', '\n': '\n', '\t': '\t'
        };
        
        for (const [orkhon, latin] of Object.entries(reverseMap)) {
            result = result.replace(new RegExp(orkhon, 'g'), latin);
        }
        
        // سون دوزلتمه: اگه törk وارسا türk-ه چئویر
        result = result.replace(/törk/gi, 'türk');
        
        return result;
    },

    // اساس چئویرمه تابعی
    convert(text, mode) {
        if (mode === 'latin-to-orkhon') {
            return this.convertToOldTurkic(text);
        } else {
            return this.convertToLatin(text);
        }
    }
};

// ====== چئویریچی ویجتینین تنظیملری ======
function setupOrkhonConverter() {
    const modeBtns = document.querySelectorAll('.mode-btn');
    const swapBtn = document.getElementById('swapBtn');
    const clearBtn = document.getElementById('clearBtn');
    const inputText = document.getElementById('inputText');
    const outputText = document.getElementById('outputText');
    const inputLabel = document.getElementById('inputLabel');
    const outputLabel = document.getElementById('outputLabel');

    let currentMode = 'latin-to-orkhon';

    function updateUI() {
        if (currentMode === 'latin-to-orkhon') {
            inputLabel.textContent = '';
            inputText.placeholder = 'لاتین الیفباسی ایله یازین ...';
            outputLabel.textContent = '';
            outputText.placeholder = 'اورخون الیفباسی ایله سونوج ...';
        } else {
            inputLabel.textContent = '';
            inputText.placeholder = 'اورخون الیفباسی ایله یازین  ...';
            outputLabel.textContent = '';
            outputText.placeholder = ' لاتین الیفباسی ایله سونوج...';
        }
        
        modeBtns.forEach(btn => {
            btn.classList.toggle('active', btn.dataset.mode === currentMode);
        });
        
        if (inputText.value) {
            const converted = orkhonConverter.convert(inputText.value, currentMode);
            outputText.value = converted;
        }
    }

    // eventلر
    modeBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            currentMode = this.dataset.mode;
            updateUI();
            inputText.focus();
        });
    });

    if (swapBtn) {
        swapBtn.addEventListener('click', function() {
            currentMode = currentMode === 'latin-to-orkhon' ? 'orkhon-to-latin' : 'latin-to-orkhon';
            const temp = inputText.value;
            inputText.value = outputText.value;
            outputText.value = orkhonConverter.convert(temp, currentMode);
            updateUI();
        });
    }

    inputText.addEventListener('input', function() {
        const converted = orkhonConverter.convert(this.value, currentMode);
        outputText.value = converted;
    });

    if (clearBtn) {
        clearBtn.addEventListener('click', function() {
            inputText.value = '';
            outputText.value = '';
            inputText.focus();
        });
    }

    // قیسا yol کلیدلری
    inputText.addEventListener('keydown', function(e) {
        if (e.ctrlKey && e.key === 'Delete') {
            e.preventDefault();
            if (clearBtn) clearBtn.click();
        }
        if (e.ctrlKey && e.key === 's') {
            e.preventDefault();
            if (swapBtn) swapBtn.click();
        }
        if (e.ctrlKey && e.key === 'Enter') {
            const currentPos = e.target.selectionStart;
            const textBefore = e.target.value.substring(0, currentPos);
            const textAfter = e.target.value.substring(currentPos);
            e.target.value = textBefore + '\n' + textAfter;
            e.target.selectionStart = e.target.selectionEnd = currentPos + 1;
            e.preventDefault();
            
            const converted = orkhonConverter.convert(e.target.value, currentMode);
            outputText.value = converted;
        }
    });

    // نمونه‌ای اولاندان
    setTimeout(() => {
        if (!inputText.value) {
            const sampleText = currentMode === 'latin-to-orkhon' ? 
                "TÜRK" : "𐱅𐰇𐰼𐰜";
            
            inputText.value = sampleText;
            outputText.value = orkhonConverter.convert(sampleText, currentMode);
            
            setTimeout(() => {
                if (inputText.value === sampleText) {
                    inputText.value = '';
                    outputText.value = '';
                }
            }, 5000);
        }
    }, 500);

    inputText.focus();
}